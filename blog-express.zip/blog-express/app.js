var createError = require('http-errors'); //检验错误页的处理
var express = require('express');
var path = require('path');
var cookieParser = require('cookie-parser'); //解析cookie
var logger = require('morgan');		//实现记录过程 log 自动生成日志，需要配置
const session = require('express-session')
const RedisStore = require('connect-redis')(session) //redis
// var indexRouter = require('./routes/index');
// var usersRouter = require('./routes/users');

var userRouter = require('./routes/user');
var blogRouter = require('./routes/blog');

var app = express();  //初始化app 监听客户端访问，每次访问都会形成一个实例

// view engine setup   视图引擎的设置   即前端   可注释，（只做后台）
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'jade');

app.use(logger('dev'));

app.use(express.json()); //数据处理
app.use(express.urlencoded({ extended: false }));//处理格式兼容
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public'))); //设置静态文件

const redisClient = require('./db/redis')	//redis 的使用
const sessionStore = new RedisStore({
	client:redisClient
})
//session 是服务端得一个存储工具，cookie是客户端的存储工具
app.use(session({
	secret:'asdfasd', //密匙 也是一个密码
	cookie:{ //cookie 配置
		path:'/',	//根目标，每个页面都可使用	
		httpOnly:true,	//前端js不能改，后台才能改
		maxAge: 24*60*60*1000 	//过期时间 24小时后失效
	},
	store:sessionStore //之前没有store，session是存到内存中去的。有store后session存放到redis里面去了
}))

//注册路由
// app.use('/', indexRouter); //根路径
// app.use('/users', usersRouter);
app.use('/api/blog', blogRouter); 
app.use('/api/user', userRouter);


// catch 404 and forward to error handler   检验错误页的处理
app.use(function(req, res, next) {
  next(createError(404));
});

// error handler  抛错处理， 区分环境  dev对应package.json里面的dev
app.use(function(err, req, res, next) {
  // set locals, only providing error in development
  res.locals.message = err.message;
  //如果是开发环境就抛错，如果不是就抛一个空对象
  res.locals.error = req.app.get('env') === 'dev' ? err : {};

  // render the error page
  res.status(err.status || 500);
  res.render('error');
});

module.exports = app;
