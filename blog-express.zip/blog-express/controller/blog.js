const { exec }  = require('../db/mysql.js')

const getList = (author, keyword) => {
	// console.log('11111111111111111111111111')
	let sql = `select * from blogs where 1=1 `
	if(author){
		sql += ` and author='${author}' `
	}
	if(keyword){
		sql += ` and title like '%${keyword}%' `
	}
	
	sql+= ' order by createtime desc'
				console.log(sql,',,,,')
	//返回的是promise
	return exec(sql)
}

const getDetail = (id) => {
	const sql = `select * from blogs where id ='${id}'`
	return exec(sql).then(rows =>{
		return rows[0]
	})
	/* return {
			id:2,
			title:'标题B',
			content:'内容B',
			createTime:1546610524373,
			author:'李四'
		} */ 
	
}

const newBolg = (blogData = {}) =>{
	const title = blogData.title
	const author = blogData.author	
	const createtime = Date.now()
	const content = blogData.content
	const sql = `insert into blogs (title, content, author, createtime) 
	values ('${title}', '${content}','${author}', ${createtime}) `
	return exec(sql).then(insertData =>{
		// console.log(insertData)
		return {
			id:insertData.insertId
		}
	})
	// console.log(blogData)
	// return {
	// 	id:3	//表示插入数据库里面的id		
	// }
}

const updateBlog = (id, blogData = {}) =>{
	console.log('更新成功')
	const title = blogData.title;
	const content = blogData.content
	const sql = `
	update blogs set title = '${title}' , content = '${content}' where id = '${id}'
	`
	return exec(sql).then(updateData =>{
		console.log('updateData is ' , updateData)
		if(updateData.affectedRows >0 ){
			return true
		}
		return false
	})
}

const  delBlog = (id, author) => {
	
	const sql = `delete from blogs where id = '${id}' and author = '${author}'`
	return exec(sql).then(delData =>{
		if(delData.affectedRows >0){
			return true
		}
		return false
	})
	
}
module.exports = {
	getList,
	getDetail,
	newBolg,
	delBlog,
	updateBlog
}