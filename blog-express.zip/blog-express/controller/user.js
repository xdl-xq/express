const { exec, escape }  = require('../db/mysql.js')


//引入密码加密
// const { genPassword } = require('../src/utils/cryp.js')


const login = (username, password) =>{
	username = escape(username)
	//生成加密密码
	// password = genPassword(password)
	
	password = escape(password)
	
	
	
	// const sql = `select * from users where username='${username}' and password='${password}'`
	
	const sql = `select username, realname from users where username=${username} and password =${password}`	
	return exec(sql).then(rows =>{		
		return rows[0] || {}
	})
	
	// if(username == 'zhangshan' && password == '123'){
	// 	return true
	// }
	// return false
}

module.exports = {
	login
}