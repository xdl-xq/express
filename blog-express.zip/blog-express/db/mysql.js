const mysql = require('mysql');
// const { MYSQL_CONFIG } = require('../config/db.js')

const MYSQL_CONFIG = {
		host:'localhost',
		user:'root',
		password:'qz123456',
		port:'3306',
		database:'myblog'
	}
//创建连接对象
const con = mysql.createConnection(MYSQL_CONFIG)

//开始连接数据库
con.connect()

// const sql = 'select * from blogs where 1=1  order by createtime desc';
// con.query(sql,(err,result)=>{
// 	if(err){
// 		console.error(err)
// 	}
// 	console.log(result)
// })
//统一执行sql的函数

function exec(sql){
	const promise = new Promise((resolve,reject)=>{
		//console.log(sql)
		con.query(sql, (err,result) =>{
			if(err){
				reject(err)
				return 
			}
			resolve(result)
			// console.log(result)
		})
	})
	return promise
}

module.exports = {
	exec,
	escape:mysql.escape //防止mysql注入
}
