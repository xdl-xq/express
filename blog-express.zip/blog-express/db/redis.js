//封装使用
const redis = require('redis')
const {REDIS_CONFIG} = require('../config/db')

const redisClient = redis.createClient(REDIS_CONFIG.port,REDIS_CONFIG.host)
redisClient.on('err',err =>{
	if(err){
		console.error(err)
	}
})

function set(key,val){
	if(typeof val ==='object'){
		val = JSON.stringify(val)
	}
	redisClient.set(key,val,redis.print)
}

function get(key){
	const promise = new Promise((resolve,reject) =>{
		redisClient.get(key, (err,val) =>{
			if(err){
				reject(err)
				return
			}
			if(val == null){
				resolve(null)
			}
			try{ //不是为了抛出什么异常，把val 转成对象  为了json格式
				resolve(
					JSON.parse(val)
				)
			}catch(e){
				resolve(val)
				//TODO handle the exception
			}			
		})
	})
	return promise
}

module.exports = redisClient