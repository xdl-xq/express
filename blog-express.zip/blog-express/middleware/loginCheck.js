const { SuccessModel, ErrorModel } = require('../model/resModel.js')

//直接输出中间件函数
module.exports = (req, res, next) =>{
	if(req.session.username){
		next()
		return
	}
	res.json(
		new ErrorModel('未登录')
	)
}