var express = require('express')
var router = express.Router();
const { SuccessModel, ErrorModel } = require('../model/resModel.js')
const { getList, getDetail, newBolg, updateBlog, delBlog } = require('../controller/blog.js')

//引入登录验证中间件
const loginCheck = require('../middleware/loginCheck')
router.get('/list',function(req, res, next){
	// res.json({
	// 	errno:0,
	// 	data:[1,2,3]
	// })
	console.log('获取列表')
	let author = req.query.author || ''
	const keywork = req.query.keywork || ''
	if(req.query.isadmin){
		if(req.session.username == null){
			res.json(new ErrorModel('未登录'))
			return
		}
		//强制查询自己的博客
		// author = req.session.username
	}	
	const result =  getList(author, keywork)	
	return result.then( listData => {
		res.json(new SuccessModel(listData))
	})
})

router.get('/detail',function(req, res, next){
	const id = req.query.id
	const result = getDetail(id)
	return result.then(data =>{
		res.json(new SuccessModel(data))
	})
})

router.post('/new', loginCheck, (req, res, next) => {
	
	let blogData = req.body
	blogData.author = req.session.username 
	const result = newBolg(blogData)
	return result.then(data =>{
		res.json(new SuccessModel(data))
	})	
})

router.post('/update', loginCheck, (req, res, next) =>{	
	const blogData = req.body
	const id = req.query.id
	const result = updateBlog(id, blogData)
	return result.then( val =>{
		if(val){
			res.json( new SuccessModel())
		}else {
			res.json( new ErrorModel('更新博客失败'))
		}
	})
})


router.post('/del', loginCheck, (req, res, next) =>{
	const id = req.query.id
	const author = req.session.username
	const result = delBlog(id,author)		
	return result.then(val =>{
		if(val){
			res.json( new SuccessModel())
		}else {
			res.json( new ErrorModel('删除失败'))
		}
	})
})

module.exports = router