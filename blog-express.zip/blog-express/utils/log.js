const fs = require('fs')
const path = require('path')

//写日志函数
function writeLog(writeStream,log){
	// console.log('进入访问日志2')
	writeStream.write(log+'\n')		//关键代码
}


//生成 write stream 水桶
function createWriteStream(fileName){
	// console.log('进入访问日志3')
	//                             路径拼接 
	const fullFileName = path.join(__dirname,'../','../','logs',fileName)
	const writeStream = fs.createWriteStream(fullFileName,{
		flags:'a'
	})
	return writeStream
}


//写访问日志
const accessWriteStream =createWriteStream('access.log')
function access(log){
	console.log('进入访问日志')
	writeLog(accessWriteStream, log)
}

module.exports = {
	access
}