
//日志文件分析

const fs = require('fs')
const path = require('path')
const readline = require('readline')


const fileName = path.join(__dirname,'../','../','logs','access.log')
const readStream = fs.createReadStream(fileName)

//创建readline对象
const rl = readline.createInterface({
	input: readStream
})

let chromeNum = 0
let countNum = 0

//z逐行读取
rl.on('line', (lineData) =>{
	if(!lineData){
		return
	}
	console.log(lineData)
	countNum++
	const arr = lineData.split(' -- ')
	if(arr[2] && arr[2].indexOf('chrome') >0){
		//累加 chrome的数量
		chromeNum++
	}
})

//监听读取完成
rl.on('close', () => {
	console.log(countNum +'---'+chromeNum)
	
})